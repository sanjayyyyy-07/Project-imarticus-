# TaskFlow – MERN Task Management App

A full-stack task manager built with **MongoDB, Express, React and Node.js**. Users register, log in with JWT authentication, and manage their own tasks from a responsive dashboard.

- **Live app:** `<add your Netlify/Vercel URL>`
- **Live API:** `<add your Render URL>`
- **GitHub:** `<add your repo URL>`

---

## Part A – Plan

### 1. Problem statement
Students and working professionals track their work in notebooks, spreadsheets and chat apps, which are scattered, easy to lose and not accessible everywhere. TaskFlow gives each user a secure personal account and one place to create, prioritise, update and review tasks from a laptop or phone.

### 2. Main features
- Register and log in securely (bcrypt-hashed passwords, JWT sessions)
- Create tasks with title, description, due date, priority (Low/Medium/High) and status (Pending/In Progress/Completed)
- Edit, delete and quickly change the status of tasks
- Dashboard summary: total, pending, in progress and completed counts, plus upcoming deadlines
- Filter tasks by status; overdue tasks are highlighted
- Each user sees and manages only their own tasks
- Responsive Bootstrap layout with a collapsible navigation bar
- Loading, success and error messages throughout

### 3. Wireframes (sketch)

```
Login / Register              Dashboard
+---------------------+       +-----------------------------------------+
| TaskFlow   Login Reg|       | TaskFlow  Dashboard  My Tasks  Hi, X [Logout] |
+---------------------+       +-----------------------------------------+
|  Welcome back       |       | Hello, X                  [Manage tasks]|
|  Email [__________] |       | +-------+ +-------+ +-------+ +-------+ |
|  Pass  [__________] |       | | Total | |Pending| |In Prog| | Done  | |
|  [   Log in      ]  |       | +-------+ +-------+ +-------+ +-------+ |
|  New here? Register |       | Upcoming deadlines                      |
+---------------------+       |  - Task A ........ 20/11/2026           |
                              +-----------------------------------------+

Task Management
+-----------------------------------------------------------+
| My Tasks                                      [+ New task]|
| [ New/Edit form: title, description, date, priority, status]|
| Show: [All v]                                             |
| +-------------------------------------------------------+ |
| | Task title                     [High] [In Progress]   | |
| | Description...                                        | |
| | Due: 20/11/2026                                       | |
| | [Status v] [Edit] [Delete]                            | |
| +-------------------------------------------------------+ |
+-----------------------------------------------------------+
```

### 4. React components
| Component | Purpose |
|---|---|
| `App` | Route definitions |
| `AuthProvider` (context) | Holds user and token, `login()` / `logout()` |
| `Navbar` | Responsive navigation and logout |
| `ProtectedRoute` | Redirects unauthenticated users to login |
| `Register`, `Login` | Auth pages with validation |
| `Dashboard` | Task statistics and upcoming deadlines |
| `Tasks` | Task page: list, filter, create, edit, delete |
| `TaskForm` | Create/edit form with validation |
| `TaskItem` | Single task card with status change, edit, delete |

### 5. Database collections
**users**
| Field | Type |
|---|---|
| name | String |
| email | String (unique) |
| password | String (bcrypt hash) |
| createdAt | Date |

**tasks**
| Field | Type |
|---|---|
| title | String (required) |
| description | String |
| dueDate | Date |
| priority | Low / Medium / High |
| status | Pending / In Progress / Completed |
| user | ObjectId → users |
| createdAt | Date |

### 6. Architecture

```
+----------------+   HTTPS / JSON (Axios)   +-----------------+   Mongoose   +---------------+
| React (Vite)   | -----------------------> | Express + Node  | -----------> | MongoDB Atlas |
| Netlify/Vercel | <----------------------- | Render          | <----------- |               |
+----------------+     JWT in header        +-----------------+              +---------------+
```

1. The React app sends requests with `Authorization: Bearer <token>`.
2. Express middleware verifies the JWT and sets `req.userId`.
3. Routes query MongoDB through Mongoose, always filtering by `user`.
4. JSON responses return to the client, which updates its state.

---

## API reference

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | No | Create account, returns token and user |
| POST | `/api/auth/login` | No | Log in, returns token and user |
| GET | `/api/tasks` | Yes | List the logged-in user's tasks |
| POST | `/api/tasks` | Yes | Create a task |
| PUT | `/api/tasks/:id` | Yes | Update a task (own tasks only) |
| DELETE | `/api/tasks/:id` | Yes | Delete a task (own tasks only) |

Errors return `{ "message": "..." }` with status 400, 401, 404, 409 or 500.

---

## Run locally

Prerequisites: Node.js 18+ and a MongoDB Atlas connection string (or local MongoDB).

```bash
# 1. Backend
cd server
cp .env.example .env      # then fill in MONGO_URI and JWT_SECRET
npm install
npm run dev               # http://localhost:5000

# 2. Frontend (new terminal)
cd client
cp .env.example .env      # VITE_API_URL=http://localhost:5000
npm install
npm run dev               # http://localhost:5173
```

---

## Deployment

### 1. Push to GitHub
```bash
cd task-manager
git init
git add .
git commit -m "MERN task manager"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```
`.env` files are git-ignored, so no secrets are pushed.

### 2. Database – MongoDB Atlas
1. Create a free cluster and a database user.
2. Network Access → allow `0.0.0.0/0` (needed for Render's changing IPs).
3. Copy the connection string and add the database name, e.g. `.../taskmanager?retryWrites=true&w=majority`.

### 3. Backend – Render (Web Service)
- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Environment variables:
  - `MONGO_URI` – your Atlas string
  - `JWT_SECRET` – a long random string
  - `CLIENT_URL` – your frontend URL (add after step 4), e.g. `https://your-app.netlify.app`

Open the Render URL; you should see `{"message":"Task Manager API is running"}`.

### 4. Frontend – Netlify or Vercel
- Base/root directory: `client`
- Build command: `npm run build`
- Publish/output directory: `dist`
- Environment variable: `VITE_API_URL` = your Render URL (no trailing slash)

SPA refresh handling is already configured (`client/public/_redirects` for Netlify, `client/vercel.json` for Vercel).

### 5. Finish CORS
Set `CLIENT_URL` on Render to the final frontend URL (no trailing slash; comma-separate multiple origins) and redeploy the backend.

### Test checklist
- [ ] Register, log in, and log out on the live site
- [ ] Wrong password shows an error message
- [ ] Create, edit, change status and delete a task
- [ ] Dashboard counts update accordingly
- [ ] Refresh `/tasks` and `/dashboard`: page loads and tasks remain
- [ ] Works on a phone screen (menu collapses into a toggle)
- [ ] Second account cannot see the first account's tasks

> Note: Render's free tier sleeps when idle, so the first request after inactivity can take around 30–60 seconds. Check each platform's current free-tier terms.

---

## Security notes
- Passwords are hashed with bcrypt before storage and never returned by the API.
- JWT secret and database credentials live only in server environment variables.
- Task queries always include the authenticated user's ID, so users cannot access each other's data.
- CORS is limited to the configured frontend origin(s).
