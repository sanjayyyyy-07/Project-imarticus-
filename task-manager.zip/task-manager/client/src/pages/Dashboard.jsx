import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    api
      .get('/tasks')
      .then((res) => setTasks(res.data))
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  const count = (status) => tasks.filter((t) => t.status === status).length;

  const stats = [
    { label: 'Total tasks', value: tasks.length, cls: 'stat-total' },
    { label: 'Pending', value: count('Pending'), cls: 'stat-pending' },
    { label: 'In progress', value: count('In Progress'), cls: 'stat-progress' },
    { label: 'Completed', value: count('Completed'), cls: 'stat-done' },
  ];

  const upcoming = tasks
    .filter((t) => t.status !== 'Completed' && t.dueDate)
    .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
    .slice(0, 5);

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h1 className="h3 mb-0">Hello, {user?.name} 👋</h1>
        <Link to="/tasks" className="btn btn-primary">Manage tasks</Link>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" />
          <p className="mt-2 text-muted">Loading your tasks…</p>
        </div>
      ) : (
        <>
          <div className="row g-3 mb-4">
            {stats.map((s) => (
              <div className="col-6 col-lg-3" key={s.label}>
                <div className={`card stat-card ${s.cls}`}>
                  <div className="card-body">
                    <div className="text-muted small">{s.label}</div>
                    <div className="display-6 fw-semibold">{s.value}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="card task-card">
            <div className="card-body">
              <h2 className="h5 mb-3">Upcoming deadlines</h2>
              {upcoming.length === 0 ? (
                <p className="text-muted mb-0">No upcoming deadlines. Nice and clear!</p>
              ) : (
                <ul className="list-group list-group-flush">
                  {upcoming.map((t) => (
                    <li
                      key={t._id}
                      className="list-group-item d-flex justify-content-between align-items-center px-0"
                    >
                      <span>{t.title}</span>
                      <span className="text-muted small">
                        {new Date(t.dueDate).toLocaleDateString()}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}
