import { useEffect, useState } from 'react';
import api, { errorMessage } from '../api.js';
import TaskForm from '../components/TaskForm.jsx';
import TaskItem from '../components/TaskItem.jsx';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [statusFilter, setStatusFilter] = useState('All');

  useEffect(() => {
    api
      .get('/tasks')
      .then((res) => setTasks(res.data))
      .catch((err) => setError(errorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  const flash = (msg) => {
    setSuccess(msg);
    setTimeout(() => setSuccess(''), 3000);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditing(null);
  };

  const handleSave = async (data) => {
    setSaving(true);
    setError('');
    try {
      if (editing) {
        const res = await api.put(`/tasks/${editing._id}`, data);
        setTasks(tasks.map((t) => (t._id === editing._id ? res.data : t)));
        flash('Task updated');
      } else {
        const res = await api.post('/tasks', data);
        setTasks([res.data, ...tasks]);
        flash('Task created');
      }
      closeForm();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (task) => {
    if (!window.confirm(`Delete "${task.title}"?`)) return;
    setError('');
    try {
      await api.delete(`/tasks/${task._id}`);
      setTasks(tasks.filter((t) => t._id !== task._id));
      flash('Task deleted');
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const handleStatusChange = async (task, status) => {
    setError('');
    try {
      const res = await api.put(`/tasks/${task._id}`, { status });
      setTasks(tasks.map((t) => (t._id === task._id ? res.data : t)));
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const startEdit = (task) => {
    setEditing(task);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const visible =
    statusFilter === 'All' ? tasks : tasks.filter((t) => t.status === statusFilter);

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <h1 className="h3 mb-0">My Tasks</h1>
        {!showForm && (
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            + New task
          </button>
        )}
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      {showForm && (
        <div className="card task-card mb-4">
          <div className="card-body">
            <h2 className="h5 mb-3">{editing ? 'Edit task' : 'New task'}</h2>
            {/* key forces the form to reset when switching between tasks */}
            <TaskForm
              key={editing ? editing._id : 'new'}
              task={editing}
              onSubmit={handleSave}
              onCancel={closeForm}
              saving={saving}
            />
          </div>
        </div>
      )}

      <div className="mb-3 d-flex align-items-center gap-2">
        <label htmlFor="filter" className="small text-muted">Show:</label>
        <select
          id="filter"
          className="form-select form-select-sm w-auto"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option>All</option>
          <option>Pending</option>
          <option>In Progress</option>
          <option>Completed</option>
        </select>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" />
          <p className="mt-2 text-muted">Loading tasks…</p>
        </div>
      ) : visible.length === 0 ? (
        <div className="text-center text-muted py-5">
          {tasks.length === 0
            ? 'No tasks yet. Click "New task" to add your first one.'
            : 'No tasks match this filter.'}
        </div>
      ) : (
        visible.map((t) => (
          <TaskItem
            key={t._id}
            task={t}
            onEdit={startEdit}
            onDelete={handleDelete}
            onStatusChange={handleStatusChange}
          />
        ))
      )}
    </>
  );
}
