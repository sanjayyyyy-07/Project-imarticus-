import { useState } from 'react';

const empty = { title: '', description: '', dueDate: '', priority: 'Medium', status: 'Pending' };

const toForm = (task) =>
  task
    ? {
        title: task.title,
        description: task.description || '',
        dueDate: task.dueDate ? task.dueDate.slice(0, 10) : '',
        priority: task.priority,
        status: task.status,
      }
    : empty;

export default function TaskForm({ task, onSubmit, onCancel, saving }) {
  const [form, setForm] = useState(toForm(task));
  const [error, setError] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setError('Title is required');
      return;
    }
    setError('');
    onSubmit({ ...form, title: form.title.trim(), dueDate: form.dueDate || null });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="mb-3">
        <label className="form-label" htmlFor="title">Title</label>
        <input
          id="title"
          name="title"
          className={`form-control${error ? ' is-invalid' : ''}`}
          value={form.title}
          onChange={handleChange}
          maxLength={120}
        />
        <div className="invalid-feedback">{error}</div>
      </div>
      <div className="mb-3">
        <label className="form-label" htmlFor="description">Description</label>
        <textarea
          id="description"
          name="description"
          rows="3"
          className="form-control"
          value={form.description}
          onChange={handleChange}
        />
      </div>
      <div className="row g-3 mb-3">
        <div className="col-12 col-md-4">
          <label className="form-label" htmlFor="dueDate">Due date</label>
          <input
            id="dueDate"
            name="dueDate"
            type="date"
            className="form-control"
            value={form.dueDate}
            onChange={handleChange}
          />
        </div>
        <div className="col-6 col-md-4">
          <label className="form-label" htmlFor="priority">Priority</label>
          <select
            id="priority"
            name="priority"
            className="form-select"
            value={form.priority}
            onChange={handleChange}
          >
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>
        </div>
        <div className="col-6 col-md-4">
          <label className="form-label" htmlFor="status">Status</label>
          <select
            id="status"
            name="status"
            className="form-select"
            value={form.status}
            onChange={handleChange}
          >
            <option>Pending</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
        </div>
      </div>
      <div className="d-flex gap-2">
        <button className="btn btn-primary" disabled={saving}>
          {saving ? 'Saving…' : task ? 'Update task' : 'Add task'}
        </button>
        {onCancel && (
          <button type="button" className="btn btn-outline-secondary" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
