import { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, token, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    setOpen(false);
    navigate('/login');
  };

  const linkClass = ({ isActive }) => `nav-link${isActive ? ' active fw-semibold' : ''}`;

  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-primary">
      <div className="container">
        <Link className="navbar-brand fw-bold" to={token ? '/dashboard' : '/login'}>
          TaskFlow
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          aria-label="Toggle navigation"
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className={`collapse navbar-collapse${open ? ' show' : ''}`}>
          <ul className="navbar-nav me-auto">
            {token && (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/dashboard" onClick={() => setOpen(false)}>
                    Dashboard
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/tasks" onClick={() => setOpen(false)}>
                    My Tasks
                  </NavLink>
                </li>
              </>
            )}
          </ul>
          <ul className="navbar-nav align-items-md-center gap-md-2">
            {token ? (
              <>
                <li className="nav-item text-white-50 small me-md-2">Hi, {user?.name}</li>
                <li className="nav-item">
                  <button className="btn btn-light btn-sm" onClick={handleLogout}>
                    Log out
                  </button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/login" onClick={() => setOpen(false)}>
                    Login
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/register" onClick={() => setOpen(false)}>
                    Register
                  </NavLink>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
