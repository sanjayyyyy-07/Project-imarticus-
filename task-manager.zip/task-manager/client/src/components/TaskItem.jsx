const priorityBadge = { Low: 'bg-secondary', Medium: 'bg-warning text-dark', High: 'bg-danger' };
const statusBadge = { Pending: 'bg-warning text-dark', 'In Progress': 'bg-info text-dark', Completed: 'bg-success' };

export default function TaskItem({ task, onEdit, onDelete, onStatusChange }) {
  const due = task.dueDate ? new Date(task.dueDate) : null;
  const overdue = due && task.status !== 'Completed' && due < new Date(new Date().toDateString());

  return (
    <div className={`card task-card mb-3${overdue ? ' overdue' : ''}`}>
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
          <h3 className="h5 mb-1">{task.title}</h3>
          <div className="d-flex gap-1">
            <span className={`badge ${priorityBadge[task.priority]}`}>{task.priority}</span>
            <span className={`badge ${statusBadge[task.status]}`}>{task.status}</span>
          </div>
        </div>
        {task.description && <p className="text-muted mb-2">{task.description}</p>}
        <div className="small text-muted mb-3">
          {due ? (
            <>
              Due: {due.toLocaleDateString()}
              {overdue && <span className="text-danger fw-semibold"> (overdue)</span>}
            </>
          ) : (
            'No due date'
          )}
        </div>
        <div className="d-flex flex-wrap gap-2 align-items-center">
          <select
            className="form-select form-select-sm w-auto"
            value={task.status}
            onChange={(e) => onStatusChange(task, e.target.value)}
            aria-label="Change status"
          >
            <option>Pending</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
          <button className="btn btn-sm btn-outline-primary" onClick={() => onEdit(task)}>
            Edit
          </button>
          <button className="btn btn-sm btn-outline-danger" onClick={() => onDelete(task)}>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}
