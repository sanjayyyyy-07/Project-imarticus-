const express = require('express');
const mongoose = require('mongoose');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

const router = express.Router();

// All task routes require a valid JWT
router.use(auth);

const validId = (id) => mongoose.Types.ObjectId.isValid(id);

// Only these fields may be set by the client (prevents overriding `user`)
const pick = (body) => {
  const allowed = ['title', 'description', 'dueDate', 'priority', 'status'];
  const out = {};
  allowed.forEach((k) => {
    if (body[k] !== undefined) out[k] = body[k];
  });
  return out;
};

// GET /api/tasks
router.get('/', async (req, res) => {
  try {
    const tasks = await Task.find({ user: req.userId }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ message: 'Could not fetch tasks' });
  }
});

// POST /api/tasks
router.post('/', async (req, res) => {
  try {
    const data = pick(req.body);
    if (!data.title || !data.title.trim()) {
      return res.status(400).json({ message: 'Task title is required' });
    }
    const task = await Task.create({ ...data, user: req.userId });
    res.status(201).json(task);
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    res.status(500).json({ message: 'Could not create task' });
  }
});

// PUT /api/tasks/:id
router.put('/:id', async (req, res) => {
  try {
    if (!validId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid task id' });
    }
    const data = pick(req.body);
    if (data.title !== undefined && !String(data.title).trim()) {
      return res.status(400).json({ message: 'Task title cannot be empty' });
    }
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      data,
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    res.status(500).json({ message: 'Could not update task' });
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', async (req, res) => {
  try {
    if (!validId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid task id' });
    }
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted', id: task._id });
  } catch (err) {
    res.status(500).json({ message: 'Could not delete task' });
  }
});

module.exports = router;
